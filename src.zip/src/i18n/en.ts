export const en = {
  SAVE: 'Save',
  LOGIN_PAGE: {
    TITLE: 'Login',
    USERNAME: 'Username',
    PASSWORD: 'Password',
  },
  HOME_PAGE: {
    TITLE: 'Welcome!',
  },
  TABS: {
    HOME: 'Home',
    SETTINGS: 'Settings',
  },
  SETTINGS_PAGE: {
    TITLE: 'Settings',
  },
};

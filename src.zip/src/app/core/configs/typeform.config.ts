export const TYPEFORM_FORMS = {
  feedback: {
    id: 'mibqokVS',
    typeformToken:
      'tfp_AeUj8JVK78npsqCJkBW7KtyEczb9s9FjptJKiXMuqNbn_3mQ1Lbbv8K4MKU',
  },
};

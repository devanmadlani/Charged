export const environment = {
  production: true,
  backendBaseUrl: '/',
};

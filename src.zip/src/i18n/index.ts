import { en } from './en';
import { nl } from './nl';

export const translations = {
  en,
  nl,
};

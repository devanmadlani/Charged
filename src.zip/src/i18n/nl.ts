export const nl = {
  SAVE: 'Opslaan',
  LOGIN_PAGE: {
    TITLE: 'Inloggen',
    USERNAME: 'Gebruikersnaam',
    PASSWORD: 'Wachtwoord',
  },
  HOME_PAGE: {
    TITLE: 'Welkom!',
  },
  TABS: {
    HOME: 'Thuis',
    SETTINGS: 'Instellingen',
  },
  SETTINGS_PAGE: {
    TITLE: 'Instellingen',
  },
};
